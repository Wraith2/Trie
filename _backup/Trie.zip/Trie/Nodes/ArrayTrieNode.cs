namespace Wraith.Collections.Generic
{
	using System;
	using System.Collections;
	using System.Collections.Generic;
	using System.Diagnostics;

	#region oldcode
	/*
	[DebuggerDisplay("Node({Range,nq},{((IsBranch)?\"B\":string.Empty),nq}{((TerminiatorCount>0)?\"T\":string.Empty),nq})")]
	public class ArrayTrieNode<T> : ITrieNode<T> //IEnumerable<TrieNode<T>>
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		//private IList<TrieNode<T>> children;
		private IList<ITrieNode<T>> children;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IRange<T> range;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int terminationCount;

		//[DebuggerStepThrough]
		internal ArrayTrieNode(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
		{
			this.range=range;
			//this.children=children;
			this.terminationCount=terminationCount;
			this.children=ListFromEnumerable(children,true);

			//this.root=ListFromEnumerable(children,out this.count);
			//try
			//{
			//    this.CheckConsistancy();
			//}
			//catch (Exception)
			//{
			//    this.root=ListFromEnumerable(children,out this.count);
			//}
		}
		//[Obsolete]
		[DebuggerStepThrough]
		public ArrayTrieNode(IRange<T> range)
		{
			this.range=range;
			this.terminationCount=(range!=null && range.Length>0)?1:0;
		}

		public IRange<T> Range
		{
			[DebuggerStepThrough]
			get
			{
				return this.range;
			}
			[DebuggerStepThrough]
			set
			{
				this.range=value;
			}
		}
		public int TerminiatorCount
		{
			[DebuggerStepThrough]
			get
			{
				return this.terminationCount;
			}
			[DebuggerStepThrough]
			set
			{
				this.terminationCount=value;
			}
		}
		public IEnumerable<ITrieNode<T>> Children
		{
			[DebuggerStepThrough]
			get
			{
				//if (this.children==null)
				//{
				//    this.children=new List<TrieNode<T>>();
				//}
				return this.children;
			}
			//[DebuggerStepThrough]
			//set
			//{
			//    this.children=ListFromEnumerable(value);
			//}
		}

		public bool IsTerminator
		{
			[DebuggerStepThrough]
			get
			{
				return (this.terminationCount>0);
			}
		}
		public bool IsBranch
		{
			[DebuggerStepThrough]
			get
			{
				return (this.children!=null && this.children.Count>0);
			}
		}

		public void Add(ITrieNode<T> child)
		{
			//this.CheckConsistancy();

			//if (child.Range.Start==173 && child.Range.Length==3)
			//{
			//    Debug.WriteLine("1");
			//}
			if (this.children==null)
			{
				this.children=new List<ITrieNode<T>>();
			}
			this.children.Add(child);

			//if (child.Range.Start==1078 && child.Range.Length==4)
			//{
			//    Debug.WriteLine("2");
			//}
			//this.AddNode(child);
		}
		public void Remove(ITrieNode<T> child)
		{
			//this.CheckConsistancy();

			if (this.children!=null)
			{
				this.children.Remove(child);
				if (this.children.Count==0)
				{
					this.children=null;
				}
			}

			//this.RemoveNode(child);
			
		}
		public void Clear()
		{
			//this.CheckConsistancy();

			this.range=null;
			this.children=null;
			this.terminationCount=0;

			//this.ClearNode();
		}
		public ITrieNode<T> GetFirstChild()
		{
			if (this.children.Count==0)
			{
			    throw new InvalidOperationException("node has no children");
			}
			return this.children[0];

			//this.CheckConsistancy();

			//if (this.children.Count==0)
			//{
			//    throw new InvalidOperationException("node has no children");
			//}
			//ITrieNode<T> value1=this.children[0];

			//ITrieNode<T> value2 = this.GetFirstChildNode();
			//if (value2!=value1)
			//{
			//    throw new InvalidOperationException("bad value");
			//}

			//return value1;
		}
		public int Count
		{
			get
			{
				//this.CheckConsistancy();
				int retval=0;
				if (this.children!=null)
				{
					retval=this.children.Count;
				}
				return retval;
			}
		}

		#region IEnumerable<ITrieNode<T>> Members

		public IEnumerator<ITrieNode<T>> GetEnumerator()
		{
			return (this.children!=null)?this.children.GetEnumerator():null;
		}

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		#endregion

		protected static IList<ITrieNode<T>> ListFromEnumerable(IEnumerable<ITrieNode<T>> enumerable,bool alwaysCreate)
		{
			IList<ITrieNode<T>> list = enumerable as IList<ITrieNode<T>>;
			if (list==null)
			{
				if (enumerable==null)
				{
					if (alwaysCreate)
					{
						list=new List<ITrieNode<T>>(3);
					}
				}
				else
				{
					list=new List<ITrieNode<T>>(enumerable);
				}
			}
			return list;
		}





		//[DebuggerDisplay("list({Value,nq})")]
		//public sealed class ListNode<T> : IEnumerable<T>
		//{
		//    public T Value;
		//    public ListNode<T> Next;

		//    public ListNode()
		//        : this(null,default(T))
		//    {
		//    }
		//    public ListNode(T value)
		//        : this(null,value)
		//    {
		//    }
		//    public ListNode(ListNode<T> previous)
		//        : this(previous,default(T))
		//    {

		//    }
		//    public ListNode(ListNode<T> previous,T value)
		//    {
		//        this.Value=value;
		//        this.Next=previous;
		//    }

		//    public int Count
		//    {
		//        get
		//        {
		//            int count=0;
		//            for (
		//                ListNode<T> previous=this;
		//                previous!=null;
		//                previous=previous.Next
		//            )
		//            {
		//                count+=1;
		//            }
		//            return count;
		//        }
		//    }

		//    public override string ToString()
		//    {
		//        return string.Format("[{0}]",this.Value);
		//    }

		//    public static int GetCount(ref ListNode<T> stack)
		//    {
		//        int count=0;
		//        for (
		//            ListNode<T> current=stack;
		//            current!=null;
		//            current=current.Next
		//        )
		//        {
		//            count+=1;
		//        }
		//        return count;
		//    }
		//    public static int Add(ref ListNode<T> list,T item)
		//    {
		//        if (item==null)
		//        {
		//            throw new ArgumentNullException("item","item is null");
		//        }
		//        ListNode<T> last = null;
		//        int count=0;
		//        for (ListNode<T> current=list;current!=null;current=current.Next)
		//        {
		//            if (object.Equals(current.Value,item))
		//            {
		//                throw new ArgumentException("duplicate item","item");
		//            }
		//            count+=1;
		//            last=current;
		//        }
		//        ListNode<T> add = new ListNode<T>(item);
		//        if (last!=null)
		//        {
		//            last.Next=add;
		//        }
		//        else
		//        {
		//            list=add;
		//        }
		//        count+=1;
		//        return count;
		//    }
		//    public static bool Remove(ref ListNode<T> list,T item)
		//    {
		//        if (item==null)
		//        {
		//            throw new ArgumentNullException("item","item is null");
		//        }

		//        bool retval=false;
		//        ListNode<T> previous = null;
		//        ListNode<T> current = list;
		//        for (;current!=null;current=current.Next)
		//        {
		//            if (object.Equals(current.Value,item))
		//            {
		//                break;
		//            }
		//            previous=current;
		//        }
		//        if (retval=(current!=null))
		//        {
		//            if (current==list)
		//            {
		//                list=current.Next;
		//            }
		//            else
		//            {
		//                previous.Next=current.Next;
		//            }
		//        }
		//        return retval;
		//    }
		//    public static bool Contains(ref ListNode<T> list,T item)
		//    {
		//        if (item==null)
		//        {
		//            throw new ArgumentNullException("item","item is null");
		//        }
		//        bool retval=false;
		//        for (ListNode<T> current=list;current!=null;current=current.Next)
		//        {
		//            if (retval=object.Equals(current.Value,item))
		//            {
		//                break;
		//            }
		//        }
		//        return retval;
		//    }
		//    public static void Clear(ref ListNode<T> list)
		//    {
		//        ListNode<T> previous=null;
		//        for (
		//            ListNode<T> current=list;
		//            current!=null;
		//            current=current.Next
		//        )
		//        {
		//            if (previous!=null)
		//            {
		//                previous.Next=null;
		//            }
		//            current.Value=default(T);
		//            previous=current;
		//        }
		//        //this.count=0;
		//        //this.head=null;
		//        list=null;
		//    }

		//    #region IEnumerable<T> Members

		//    public IEnumerator<T> GetEnumerator()
		//    {
		//        return new ListNodeEnumerator<T>(this);
		//    }

		//    #endregion

		//    #region IEnumerable Members

		//    IEnumerator IEnumerable.GetEnumerator()
		//    {
		//        return this.GetEnumerator();
		//    }

		//    #endregion
		//}

		//private sealed class ListNodeEnumerator<T> : IEnumerator<T>
		//{
		//    private ListNode<T> current;
		//    private ListNode<T> root;
		//    private bool start;

		//    public ListNodeEnumerator(ListNode<T> root)
		//    {
		//        this.root=root;
		//        this.start=true;
		//        this.current=null;
		//    }

		//    #region IEnumerator<T> Members

		//    public T Current
		//    {
		//        get
		//        {
		//            if (this.current==null)
		//            {
		//                throw new InvalidOperationException("enumeration has not started");
		//            }
		//            return this.current.Value;
		//        }
		//    }

		//    #endregion

		//    #region IEnumerator Members

		//    object IEnumerator.Current
		//    {
		//        get
		//        {
		//            return this.Current;
		//        }
		//    }
		//    public bool MoveNext()
		//    {
		//        if (this.start)
		//        {
		//            this.current=this.root;
		//            this.start=false;
		//        }
		//        else if (this.current!=null)
		//        {
		//            this.current=this.current.Next;
		//        }
		//        return (this.current!=null);
		//    }
		//    public void Reset()
		//    {
		//        this.start=true;
		//        this.current=null;
		//    }

		//    #endregion

		//    #region IDisposable Members

		//    public void Dispose()
		//    {
		//    }

		//    #endregion

		//}

		////[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		//private ListNode<ITrieNode<T>> root;
		////[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		//private int count;

		//public void CheckConsistancy()
		//{
		//    if (this.children==null)
		//    {
		//        if (this.count!=0)
		//        {
		//            throw new InvalidOperationException("bad count");
		//        }
		//    }
		//    else
		//    {
		//        if (this.count!=this.children.Count)
		//        {
		//            throw new InvalidOperationException("bad count");
		//        }

		//        int index=0;
		//        for (
		//            ListNode<ITrieNode<T>> current=this.root;
		//            current!=null;
		//            current=current.Next,index++
		//        )
		//        {
		//            ITrieNode<T> value1 = this.children[index];
		//            ITrieNode<T> value2 = current.Value;
		//            if (value1!=value2)
		//            {
		//                throw new InvalidOperationException("bad value");
		//            }
		//        }
		//    }
		//}

		//public void AddNode(ITrieNode<T> child)
		//{
		//    this.count=ListNode<ITrieNode<T>>.Add(ref this.root,child);
		//    this.CheckConsistancy();
		//}
		//public void RemoveNode(ITrieNode<T> child)
		//{
		//    ListNode<ITrieNode<T>>.Remove(ref this.root,child);
		//    this.count=ListNode<ITrieNode<T>>.GetCount(ref this.root);
		//    this.CheckConsistancy();
		//}
		//public void ClearNode()
		//{
		//    ListNode<ITrieNode<T>>.Clear(ref this.root);
		//    this.count=0;
		//    this.CheckConsistancy();
		//}

		//public ITrieNode<T> GetFirstChildNode()
		//{
		//    this.CheckConsistancy();
		//    if (this.root==null)
		//    {
		//        throw new InvalidOperationException("node has no children");
		//    }
		//    return this.root.Value;
			
		//}

		//protected static ListNode<ITrieNode<T>> ListFromEnumerable(IEnumerable<ITrieNode<T>> enumerable,out int count)
		//{
		//    count=0;
		//    ListNode<ITrieNode<T>> nodeList = enumerable as ListNode<ITrieNode<T>>;
		//    if (nodeList!=null)
		//    {
		//        count=ListNode<ITrieNode<T>>.GetCount(ref nodeList);
		//    }
		//    else
		//    {
		//        if (enumerable!=null)
		//        {
		//            foreach (ITrieNode<T> item in enumerable)
		//            {
		//                count=ListNode<ITrieNode<T>>.Add(ref nodeList,item);
		//            }
		//        }
		//    }
		//    return nodeList;
		//}

	}
	*/
	#endregion

	#region oldcode
	/*
	[DebuggerDisplay("Node({Range,nq},{((IsBranch)?\"B\":string.Empty),nq}{((TerminiatorCount>0)?\"T\":string.Empty),nq})")]
	public class ArrayTrieNode<T> : ATrieNode<T> 
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IList<ITrieNode<T>> children;

		//[DebuggerStepThrough]
		internal ArrayTrieNode(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
			: base(range,terminationCount)
		{
			this.children=ListFromEnumerable(children,true);
		}
		//[Obsolete]
		[DebuggerStepThrough]
		public ArrayTrieNode(IRange<T> range)
			: base(range)
		{
		}

		public override IEnumerable<ITrieNode<T>> Children
		{
			[DebuggerStepThrough]
			get
			{
				//if (this.children==null)
				//{
				//    this.children=new List<TrieNode<T>>();
				//}
				return this.children;
			}
			//[DebuggerStepThrough]
			//set
			//{
			//    this.children=ListFromEnumerable(value);
			//}
		}

		public override bool IsBranch
		{
			[DebuggerStepThrough]
			get
			{
				return (this.children!=null && this.children.Count>0);
			}
		}

		public override void Add(ITrieNode<T> child)
		{
			if (child==null)
			{
				throw new ArgumentNullException("child","child is null");
			}
			if (this.children==null)
			{
				this.children=new List<ITrieNode<T>>();
			}
			this.children.Add(child);
		}
		public override void Remove(ITrieNode<T> child)
		{
			if (child==null)
			{
				throw new ArgumentNullException("child","child is null");
			}
			if (this.children!=null)
			{
				this.children.Remove(child);
				if (this.children.Count==0)
				{
					this.children=null;
				}
			}
		}
		public override void Clear()
		{
			this.children=null;
			base.Clear();
		}
		public override ITrieNode<T> GetFirstChild()
		{
			if (this.children.Count==0)
			{
				throw new InvalidOperationException("node has no children");
			}
			return this.children[0];

			//this.CheckConsistancy();

			//if (this.children.Count==0)
			//{
			//    throw new InvalidOperationException("node has no children");
			//}
			//ITrieNode<T> value1=this.children[0];

			//ITrieNode<T> value2 = this.GetFirstChildNode();
			//if (value2!=value1)
			//{
			//    throw new InvalidOperationException("bad value");
			//}

			//return value1;
		}
		public override int Count
		{
			get
			{
				//this.CheckConsistancy();
				int retval=0;
				if (this.children!=null)
				{
					retval=this.children.Count;
				}
				return retval;
			}
		}

		#region IEnumerable<ITrieNode<T>> Members

		public override IEnumerator<ITrieNode<T>> GetEnumerator()
		{
			return (this.children!=null)?this.children.GetEnumerator():null;
		}

		#endregion

		protected static IList<ITrieNode<T>> ListFromEnumerable(IEnumerable<ITrieNode<T>> enumerable,bool alwaysCreate)
		{
			IList<ITrieNode<T>> list = enumerable as IList<ITrieNode<T>>;
			if (list==null)
			{
				if (enumerable==null)
				{
					if (alwaysCreate)
					{
						list=new List<ITrieNode<T>>(3);
					}
				}
				else
				{
					list=new List<ITrieNode<T>>(enumerable);
				}
			}
			return list;
		}
	} 
	*/
	#endregion


	[DebuggerDisplay("ALNode({Range,nq},{((IsBranch)?\"B\":string.Empty),nq}{((TerminiatorCount>0)?\"T\":string.Empty),nq})")]
	public class ArrayTrieNode<T> : ACollectionTrieNode<T>
	{
		//[DebuggerStepThrough]
		internal ArrayTrieNode(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
			: base(range,children,terminationCount)
		{
		}
		//[Obsolete]
		[DebuggerStepThrough]
		public ArrayTrieNode(IRange<T> range)
			: base(range)
		{
		}

		public override ITrieNode<T> GetFirstChild()
		{
			IList<ITrieNode<T>> children = this.Children as IList<ITrieNode<T>>;
			if (children==null)
			{
				throw new InvalidOperationException("node has no children");
			}
			if (children.Count==0)
			{
				throw new InvalidOperationException("node has no children");
			}
			return children[0];
		}

		protected override ICollection<ITrieNode<T>> CreateCollection(IEnumerable<ITrieNode<T>> enumerable)
		{
			IList<ITrieNode<T>> list = enumerable as IList<ITrieNode<T>>;
			if (list==null)
			{
				if (enumerable!=null)
				{
					list=new List<ITrieNode<T>>(enumerable);
					if (list.Count==0)
					{
						list=null;
					}
				}
			}
			return list;
		}
		protected override ICollection<ITrieNode<T>> CreateCollection()
		{
			return new List<ITrieNode<T>>();
		}
	}



	public class ArrayTrieNodeStrategy<T> : ITrieNodeStrategy<T>
	{
		private readonly TrieOptions options;

		public ArrayTrieNodeStrategy(TrieOptions options)
		{
			this.options=options;
		}

		#region ITrieNodeStrategy<T> Members

		public ITrieNode<T> Create(IRange<T> range)
		{
			return new ArrayTrieNode<T>(range,null,((range!=null && range.Length>0)?1:0));
		}

		public ITrieNode<T> Create(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
		{
			return new ArrayTrieNode<T>(range,children,terminationCount);
		}

		public TrieOptions Options
		{
			get
			{
				return this.options;
			}
		}

		#endregion
	}
}
