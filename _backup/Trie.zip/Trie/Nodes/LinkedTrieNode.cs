namespace Wraith.Collections.Generic
{
	using System;
	using System.Collections;
	using System.Collections.Generic;
	using System.Diagnostics;

	#region very old code
	/*
	[DebuggerDisplay("link( {Range,nq} )")]
	public class LinkedTrieNode<T> : ITrieNode<T>
	{
		[DebuggerTypeProxy(typeof(LinkedTrieNode<>.ListNodeDebugView<>))]
		public sealed class ListNode<T> : IEnumerable<T>
		{
			public T Value;
			public ListNode<T> Next;

			public ListNode()
				: this(null,default(T))
			{
			}
			public ListNode(T value)
				: this(null,value)
			{
			}
			public ListNode(ListNode<T> previous)
				: this(previous,default(T))
			{

			}
			public ListNode(ListNode<T> previous,T value)
			{
				if (value==null)
				{
					throw new ArgumentNullException("valuel","value is null");
				}
				this.Value=value;
				this.Next=previous;
			}

			public int Count
			{
				get
				{
					int count=0;
					for (
						ListNode<T> previous=this;
						previous!=null;
						previous=previous.Next
					)
					{
						count+=1;
					}
					return count;
				}
			}

			public override string ToString()
			{
				return string.Format("[{0}]",this.Value);
			}

			public static int GetCount(ref ListNode<T> stack)
			{
				int count=0;
				for (
					ListNode<T> current=stack;
					current!=null;
					current=current.Next
				)
				{
					count+=1;
				}
				return count;
			}
			public static int Add(ref ListNode<T> list,T item)
			{
				if (item==null)
				{
					throw new ArgumentNullException("item","item is null");
				}
				ListNode<T> last = null;
				int count=0;
				for (ListNode<T> current=list;current!=null;current=current.Next)
				{
					if (object.Equals(current.Value,item))
					{
						throw new ArgumentException("duplicate item","item");
					}
					count+=1;
					last=current;
				}
				ListNode<T> add = new ListNode<T>(item);
				if (last!=null)
				{
					last.Next=add;
				}
				else
				{
					list=add;
				}
				count+=1;
				return count;
			}
			public static bool Remove(ref ListNode<T> list,T item)
			{
				if (item==null)
				{
					throw new ArgumentNullException("item","item is null");
				}

				bool retval=false;
				ListNode<T> previous = null;
				ListNode<T> current = list;
				for (;current!=null;current=current.Next)
				{
					if (object.Equals(current.Value,item))
					{
						break;
					}
					previous=current;
				}
				if (retval=(current!=null))
				{
					if (current==list)
					{
						list=current.Next;
					}
					else
					{
						previous.Next=current.Next;
					}
				}
				return retval;
			}
			public static bool Contains(ref ListNode<T> list,T item)
			{
				if (item==null)
				{
					throw new ArgumentNullException("item","item is null");
				}
				bool retval=false;
				for (ListNode<T> current=list;current!=null;current=current.Next)
				{
					if (retval=object.Equals(current.Value,item))
					{
						break;
					}
				}
				return retval;
			}
			public static void Clear(ref ListNode<T> list)
			{
				ListNode<T> previous=null;
				for (
					ListNode<T> current=list;
					current!=null;
					current=current.Next
				)
				{
					if (previous!=null)
					{
						previous.Next=null;
					}
					current.Value=default(T);
					previous=current;
				}
				//this.count=0;
				//this.head=null;
				list=null;
			}

			#region IEnumerable<T> Members

			public IEnumerator<T> GetEnumerator()
			{
				return new ListNodeEnumerator<T>(this);
			}

			#endregion

			#region IEnumerable Members

			IEnumerator IEnumerable.GetEnumerator()
			{
				return this.GetEnumerator();
			}

			#endregion
		}

		public sealed class ListNodeDebugView<T>
		{
			private ListNode<T> root;
			private int count;

			public ListNodeDebugView(ListNode<T> root)
			{
				if (root==null)
				{
					throw new ArgumentNullException("root","root is null");
				}
				this.root=root;
			}

			//[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
			public T[] Items
			{
				get
				{
					int count= this.Count;
					T[] retval = new T[count];
					int index=0;
					for (
						ListNode<T> current=this.root;
						current!=null;
						current=current.Next,index++
					)
					{
						retval[index]=current.Value;
					}
					return retval;
				}
			}

			public int Count
			{
				get
				{
					this.count = ListNode<T>.GetCount(ref this.root);
					return this.count;
				}
			}


		}

		private sealed class ListNodeEnumerator<T> : IEnumerator<T>
		{
			private ListNode<T> current;
			private ListNode<T> root;
			private bool start;

			[DebuggerStepThrough]
			public ListNodeEnumerator(ListNode<T> root)
			{
				if (root==null)
				{
					throw new ArgumentNullException("root","root is null");
				}
				if (root.Value==null)
				{
					throw new ArgumentException("root has no value","root");
				}
				this.root=root;
				this.start=true;
				this.current=null;
			}

			#region IEnumerator<T> Members

			public T Current
			{
				//[DebuggerStepThrough]
				get
				{
					if (this.current==null)
					{
						throw new InvalidOperationException("enumeration has not started");
					}
					//if (this.current.Value==null)
					//{
					//    throw new InvalidOperationException("null value");
					//}
					return this.current.Value;
				}
			}

			#endregion

			#region IEnumerator Members

			object IEnumerator.Current
			{
				[DebuggerStepThrough]
				get
				{
					return this.Current;
				}
			}
			public bool MoveNext()
			{
				if (this.start)
				{
					this.current=this.root;
					this.start=false;
				}
				else if (this.current!=null)
				{
					this.current=this.current.Next;
				}
				return (this.current!=null);
			}
			[DebuggerStepThrough]
			public void Reset()
			{
				this.start=true;
				this.current=null;
			}

			#endregion

			#region IDisposable Members
			[DebuggerStepThrough]
			public void Dispose()
			{
			}

			#endregion

		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ListNode<ITrieNode<T>> root;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int count;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IRange<T> range;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int terminationCount;
		
		[DebuggerStepThrough]
		internal LinkedTrieNode(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
		{
			this.range=range;
			this.terminationCount=terminationCount;
			this.root=ListFromEnumerable(children,out this.count);
		}
		[Obsolete]
		[DebuggerStepThrough]
		public LinkedTrieNode(IRange<T> range)
		{
			this.range=range;
			this.terminationCount=(range!=null && range.Length>0)?1:0;
		}

		#region ITrieNode<T> Members

		public IRange<T> Range
		{
			[DebuggerStepThrough]
			get
			{
				return this.range;
			}
			set
			{
				if (value==null)
				{
					throw new InvalidOperationException("value is null");
				}
				this.range=value;
			}
		}
		public int TerminiatorCount
		{
			get
			{
				return this.terminationCount;
			}
			set
			{
				this.terminationCount=value;
			}
		}
		public IEnumerable<ITrieNode<T>> Children
		{
			get
			{
				return this.root;
			}
		}

		public bool IsTerminator
		{
			[DebuggerStepThrough]
			get
			{
				return (this.terminationCount>0);
			}
		}
		public bool IsBranch
		{
			[DebuggerStepThrough]
			get
			{
				return (this.root!=null);
			}
		}

		public void Add(ITrieNode<T> child)
		{
			if (child==null)
			{
				throw new ArgumentNullException("child","child is null");
			}
			this.count=ListNode<ITrieNode<T>>.Add(ref this.root,child);
		}
		public void Remove(ITrieNode<T> child)
		{
			ListNode<ITrieNode<T>>.Remove(ref this.root,child);
			this.count=ListNode<ITrieNode<T>>.GetCount(ref this.root);
		}
		public void Clear()
		{
			ListNode<ITrieNode<T>>.Clear(ref this.root);
			this.count=0;
		}

		public ITrieNode<T> GetFirstChild()
		{
			if (this.root==null)
			{
				throw new InvalidOperationException("node has no children");
			}
			return this.root.Value;
		}

		public int Count
		{
			get
			{
				return this.count;
			}
		}

		#endregion

		#region IEnumerable<ITrieNode<T>> Members

		public IEnumerator<ITrieNode<T>> GetEnumerator()
		{
			if (this.root==null)
			{
				throw new InvalidOperationException();
			}
			return new ListNodeEnumerator<ITrieNode<T>>(this.root);
		}

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		#endregion

		protected static ListNode<ITrieNode<T>> ListFromEnumerable(IEnumerable<ITrieNode<T>> enumerable,out int count)
		{
			count=0;
			ListNode<ITrieNode<T>> nodeList = enumerable as ListNode<ITrieNode<T>>;
			if (nodeList!=null)
			{
				count=ListNode<ITrieNode<T>>.GetCount(ref nodeList);
			}
			else
			{
				if (enumerable!=null)
				{
					foreach (ITrieNode<T> item in enumerable)
					{
						count=ListNode<ITrieNode<T>>.Add(ref nodeList,item);
					}
				}
			}
			return nodeList;
		}
	}
	*/
	#endregion

	#region oldcode
	/*
	public sealed class LinkedTrieNode<T> : ATrieNode<T>
	{
		private ICollection<ITrieNode<T>> collection;
		private int count;

		//[DebuggerStepThrough]
		internal LinkedTrieNode(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
			: base(range,terminationCount)
		{
			//this.collection=ListFromEnumerable(children);
			this.collection=LinkedListFromEnumerable(children);
		}

		[DebuggerStepThrough]
		internal LinkedTrieNode(IRange<T> range)
			: base (range)
		{

		}

		public override IEnumerable<ITrieNode<T>> Children
		{
			get
			{
				return this.collection;
			}
		}

		public override bool IsBranch
		{
			get
			{
				return (this.collection!=null && this.collection.Count>0);
			}
		}

		public override void Add(ITrieNode<T> child)
		{
			if (child==null)
			{
				throw new ArgumentNullException("child","child is null");
			}
			if (this.collection==null)
			{
				this.collection=new LinkedCollection<ITrieNode<T>>();
				//this.collection=new List<ITrieNode<T>>();
			}
			this.collection.Add(child);
			this.count-=1;
		}
		public override void Remove(ITrieNode<T> child)
		{
			if (child==null)
			{
				throw new ArgumentNullException("child","child is null");
			}
			if (this.collection!=null)
			{
				this.collection.Remove(child);
			}
			this.count=-1;
		}
		public override void Clear()
		{
			if (this.collection!=null)
			{
				this.collection.Clear();
			}
			this.count=0;
		}
		public override ITrieNode<T> GetFirstChild()
		{
			if (this.collection==null)
			{
				throw new InvalidOperationException("no collection");
			}
			if (this.collection.Count<1)
			{
				throw new InvalidOperationException("collection is empty");
			}
			//return this.collection.head.value;
			ITrieNode<T> retval=null;
			LinkedCollection<ITrieNode<T>> linked=this.collection as LinkedCollection<ITrieNode<T>>;
			if (linked!=null)
			{
				retval=linked.head.value;
			}
			else
			{
				retval=(this.collection as IList<ITrieNode<T>>)[0];
			}
			return retval;
		}

		public override int Count
		{
			get
			{
				//return ((this.collection!=null)?this.collection.Count:0);
				if (this.count==-1)
				{
					this.count=this.collection.Count;
				}
				return this.count;
			}
		}

		public override IEnumerator<ITrieNode<T>> GetEnumerator()
		{
			if (this.collection==null)
			{
				throw new InvalidOperationException("no collection");
			}
			return this.collection.GetEnumerator();
		}

		private static LinkedCollection<ITrieNode<T>> LinkedListFromEnumerable(IEnumerable<ITrieNode<T>> enumerable)
		{
			LinkedCollection<ITrieNode<T>> linkCollection = enumerable as LinkedCollection<ITrieNode<T>>;
			if (linkCollection==null)
			{
				if (enumerable!=null)
				{
					linkCollection=new LinkedCollection<ITrieNode<T>>();
					foreach (ITrieNode<T> item in enumerable)
					{
						linkCollection.Add(item);
					}
				}
			}
			return linkCollection;
		}
		private static List<ITrieNode<T>> ListFromEnumerable(IEnumerable<ITrieNode<T>> enumerable)
		{
			List<ITrieNode<T>> linkCollection = enumerable as List<ITrieNode<T>>;
			if (linkCollection==null)
			{
				if (enumerable!=null)
				{
					linkCollection=new List<ITrieNode<T>>();
					foreach (ITrieNode<T> item in enumerable)
					{
						linkCollection.Add(item);
					}
				}
			}
			return linkCollection;
		}
	} 
	*/
	#endregion


	#region oldcode
	/*
	public sealed class LinkedTrieNode<T> : ATrieNode<T>
	{
		private ICollection<ITrieNode<T>> children;		

		//[DebuggerStepThrough]
		internal LinkedTrieNode(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
			: base(range,terminationCount)
		{
			//this.collection=ListFromEnumerable(children);
			this.children=LinkedListFromEnumerable(children);
		}

		[DebuggerStepThrough]
		internal LinkedTrieNode(IRange<T> range)
			: base(range)
		{

		}

		public override IEnumerable<ITrieNode<T>> Children
		{
			get
			{
				return this.children;
			}
		}

		public override bool IsBranch
		{
			get
			{
				return (this.children!=null && this.children.Count>0);
			}
		}

		public override void Add(ITrieNode<T> child)
		{
			if (child==null)
			{
				throw new ArgumentNullException("child","child is null");
			}
			if (this.children==null)
			{
				this.children=new LinkedList<ITrieNode<T>>();
			}
			this.children.Add(child);
		}
		public override void Remove(ITrieNode<T> child)
		{
			if (child==null)
			{
				throw new ArgumentNullException("child","child is null");
			}
			if (this.children!=null)
			{
				this.children.Remove(child);
				if (this.children.Count==0)
				{
					this.children=null;
				}
			}
		}
		public override void Clear()
		{
			this.children=null;
			base.Clear();
		}
		public override ITrieNode<T> GetFirstChild()
		{
			if (this.children==null)
			{
				throw new InvalidOperationException("no collection");
			}
			if (this.children.Count<1)
			{
				throw new InvalidOperationException("collection is empty");
			}
			//return this.collection.head.value;
			return (this.children as LinkedList<ITrieNode<T>>).First.Value;
		}

		public override int Count
		{
			get
			{
				return ((this.children!=null)?this.children.Count:0);
			}
		}

		public override IEnumerator<ITrieNode<T>> GetEnumerator()
		{
			if (this.children==null)
			{
				throw new InvalidOperationException("no collection");
			}
			return this.children.GetEnumerator();
		}

		private static LinkedList<ITrieNode<T>> LinkedListFromEnumerable(IEnumerable<ITrieNode<T>> enumerable)
		{
			LinkedList<ITrieNode<T>> linkCollection = enumerable as LinkedList<ITrieNode<T>>;
			if (linkCollection==null)
			{
				if (enumerable!=null)
				{
					linkCollection=new LinkedList<ITrieNode<T>>(enumerable);
					if (linkCollection.Count==0)
					{
						linkCollection=null;
					}
				}
				
			}
			return linkCollection;
		}
	} 
	*/
	#endregion

	[DebuggerDisplay("LLNode({Range,nq},{((IsBranch)?\"B\":string.Empty),nq}{((TerminiatorCount>0)?\"T\":string.Empty),nq})")]
	public sealed class LinkedTrieNode<T> : ACollectionTrieNode<T>
	{
		//[DebuggerStepThrough]
		internal LinkedTrieNode(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
			: base(range,children,terminationCount)
		{
		}

		[DebuggerStepThrough]
		internal LinkedTrieNode(IRange<T> range)
			: base(range)
		{

		}

		public override ITrieNode<T> GetFirstChild()
		{
			LinkedList<ITrieNode<T>> children = this.Children as LinkedList<ITrieNode<T>>;
			if (children==null)
			{
				throw new InvalidOperationException("node has no children");
			}
			if (children.Count==0)
			{
				throw new InvalidOperationException("node has no children");
			}
			return children.First.Value;
		}

		protected override ICollection<ITrieNode<T>> CreateCollection(IEnumerable<ITrieNode<T>> enumerable)
		{
			LinkedList<ITrieNode<T>> linkCollection = enumerable as LinkedList<ITrieNode<T>>;
			if (linkCollection==null)
			{
				if (enumerable!=null)
				{
					linkCollection=new LinkedList<ITrieNode<T>>(enumerable);
					if (linkCollection.Count==0)
					{
						linkCollection=null;
					}
				}

			}
			return linkCollection;
		}
		protected override ICollection<ITrieNode<T>> CreateCollection()
		{
			return new LinkedList<ITrieNode<T>>();
		}
	}


	public class LinkedTrieNodeStrategy<T> : ITrieNodeStrategy<T>
	{
		private readonly TrieOptions options;

		public LinkedTrieNodeStrategy(TrieOptions options)
		{
			this.options=options;
		}

		#region ITrieNodeStrategy<T> Members

		public ITrieNode<T> Create(IRange<T> range)
		{
			return new LinkedTrieNode<T>(range,null,((range!=null && range.Length>0)?1:0));
		}
		public ITrieNode<T> Create(IRange<T> range,IEnumerable<ITrieNode<T>> children,int terminationCount)
		{
			return new LinkedTrieNode<T>(range,children,terminationCount);
		}

		public TrieOptions Options
		{
			get
			{
				return this.options;
			}
		}

		#endregion
	}
}
