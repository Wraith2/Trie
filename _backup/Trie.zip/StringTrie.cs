namespace Wraith.Collections.Generic
{
	using System;
	using System.Text;
	using System.Collections;
	using System.Collections.Generic;
	using System.Collections.Specialized;
	using System.Diagnostics;

	using Wraith.Collections.Generic;
	using Wraith.Collections;
	

	public class StringRangeStrategy : ITrieRangeStrategy<string>
	{
		#region ITrieRangeStrategy<string> Members

		public IRange<string> Create(string container,int start,int length)
		{
			return new StringRange(container,start,length,false);
		}
		public IRange<string> Merge(IRange<string> lhs,IRange<string> rhs)
		{
			if (lhs==null)
			{
				return rhs;
			}
			if (rhs==null)
			{
				return lhs;
			}
			if (lhs.Length==0)
			{
				return rhs;
			}
			if (rhs.Length==0)
			{
				return lhs;
			}

			IRange<string> merged = null;

			if (
				merged==null &&
				lhs.Container.Length>=
				(
					lhs.Start+
					lhs.Length+
					rhs.Length
				)
			)
			{
				// the lhs range.Container may include rhs range
				if (
					Match(
						lhs.Container,
						lhs.Start+lhs.Length,
						rhs.Length,
						rhs.Container,
						rhs.Start,
						rhs.Length
					)
				)
				{
					merged=Create(
							lhs.Container,
							lhs.Start,
							(lhs.Length+rhs.Length)
						);
				}
			}

			if (
				merged==null && 
				rhs.Start>=lhs.Length
				)
			{
				// the rhs range.Container may include lhs range
				if (
					Match(
						rhs.Container,
						rhs.Start-lhs.Length,
						lhs.Length,
						lhs.Container,
						lhs.Start,
						lhs.Length
					)
				)
				{
					merged=Create(
						rhs.Container,
						rhs.Start-lhs.Length,
						(lhs.Length+rhs.Length)
					);
				}
			}

			if (merged==null)
			{
				// the lhs range.Container is not followed by the rhs range
				// and the rhs range.Container is not preceeded by the lhs
				// range

				// create a new Container which contains only the required portions
				// from both lhs and rhs that are needed. this is bad and 
				// will cause fragmentation and increased memory usage.

				string newItem = string.Concat(
					lhs.Container.Substring(lhs.Start,lhs.Length),
					rhs.Container.Substring(rhs.Start,rhs.Length)
				);
				merged=Create(newItem,0,newItem.Length);
			}

			return merged;
		}
		public void Split(IRange<string> range,int length,out IRange<string> lhs,out IRange<string> rhs)
		{
			if (range==null)
			{
				throw new ArgumentException("range is null","range");
			}
			if (range.Length==0)
			{
				throw new ArgumentException("range is empty","range");
			}
			if (length<=0)
			{
				throw new ArgumentOutOfRangeException("length",length,"length must be greater than zero");
			}
			if (length>range.Length)
			{
				throw new ArgumentOutOfRangeException("length",length,"length must be less than node.Range.Length");
			}

			lhs = Create(
				range.Container,
				range.Start,
				length
			);

			rhs = Create(
				range.Container,
				range.Start+length,
				range.Length-length
			);
		}
		public bool Match(string lhs,int lhsStart,int lhsLength,string rhs,int rhsStart,int rhsLength)
		{
			bool retval=false;
			int maxMatchLength = Math.Max(lhsLength,rhsLength);

			if (maxMatchLength>0)
			{
				retval=(
					string.Compare(
							lhs,lhsStart,
							rhs,rhsStart,
							maxMatchLength,
							false
						)
					==0
				);
			}
			return retval;
		}
		public int Shared(IRange<string> lhs,int lhsOffset,IRange<string> rhs,int rhsOffset)
		{
			int retval = 0;
			int lhsLength=-1;
			int rhsLength=-1;
			int lhsStart=-1;
			int rhsStart=-1;
			if (
				lhs!=null &&
				rhs!=null &&
				(lhsLength=(lhs.Length-lhsOffset))>0 &&
				(rhsLength=(rhs.Length-rhsOffset))>0
				)
			{
				rhsStart=rhs.Start+rhsOffset;
				lhsStart=lhs.Start+lhsOffset;
				int maxMatchLength = Math.Min(lhsLength,rhsLength);
				if (maxMatchLength>0)
				{
					for (
						;
						retval<maxMatchLength;
						retval++
						)
					{
						if (
							string.Compare(
								lhs.Container,
								(lhsStart+retval),
								rhs.Container,
								(rhsStart+retval),
								1,
								false
							)!=0
						)
						{
							break;
						}
					}
				}
			}
			return retval;
		}
		public int Shared(string lhs,int lhsStart,int lhsLength,string rhs,int rhsStart,int rhsLength)
		{
			int retval = 0;
			if (
				lhs!=null &&
				rhs!=null &&
				lhsLength>0 &&
				rhsLength>0
				)
			{
				int maxMatchLength = Math.Min(lhsLength,rhsLength);
				if (maxMatchLength>0)
				{
					for (;retval<maxMatchLength;retval++)
					{
						if (
							string.Compare(
								lhs,
								(lhsStart+retval),
								rhs,
								(rhsStart+retval),
								1,
								false
							)!=0
						)
						{
							break;
						}
					}
				}
			}
			return retval;
		}
		#endregion
	}

	public class StringTrie	: Trie<string>,IEnumerable<string>
	{
		#region oldcode
		/*
		public class StringTrieEnumerator : IEnumerator<string>
		{
			[DebuggerStepThrough]
			public sealed class StringTrieEnumeratorNode
			{
				public readonly ITrieNode<string> Node;
				public readonly IEnumerator<ITrieNode<string>> Enumerator;

				public StringTrieEnumeratorNode(ITrieNode<string> Node,IEnumerator<ITrieNode<string>> Enumerator)
				{
					this.Node=Node;
					this.Enumerator=Enumerator;
				}
			}

			private StringTrie trie;
			private long verison;
			private List<StringTrieEnumeratorNode> path;
			private ITrieNode<string> current;
			private bool start;

			[DebuggerStepThrough]
			public StringTrieEnumerator(StringTrie trie)
			{
				this.trie=trie;
				this.verison=this.trie.version;
				this.path=new List<StringTrieEnumeratorNode>();
				this.Reset();
			}

			#region IEnumerator<string> Members

			public string Current
			{
				[DebuggerStepThrough]
				get
				{
					this.CheckVersion();
					return this.MakeString();
				}
			}

			public bool MoveNext()
			{
				this.CheckVersion();

				ITrieNode<string> current=this.current;
				if (this.start)
				{
					current=this.trie.Root;
					this.start=false;
				}
				ITrieNode<string> start = this.current;
				IEnumerator<ITrieNode<string>> enumerator=null;
				while (
					start==current
					||
					(
						current!=null &&
						!current.IsTerminator
					)
				)
				{
					if (current.IsBranch)
					{
						enumerator=current.GetEnumerator();
						if (!enumerator.MoveNext())
						{
							throw new InvalidOperationException("branch with no children");
						}
						this.path.Add(new StringTrieEnumeratorNode(current,enumerator));
						//if (enumerator.Current==null)
						//{
						//    //throw new InvalidOperationException("branch with null child");
						//    enumerator=current.GetEnumerator();
						//    bool result = enumerator.MoveNext();

						//}
						current=enumerator.Current;
					}
					else if (this.path.Count>0)
					{
						enumerator=this.path[this.path.Count-1].Enumerator;
						if (enumerator.MoveNext())
						{
							current=enumerator.Current;
						}
						else
						{
							this.path.RemoveAt(this.path.Count-1);
						}
					}
					else
					{
						current=null;
					}
				}
				this.current=current;

				return (this.current!=null);

			}
			[DebuggerStepThrough]
			public void Reset()
			{
				if (this.path.Count>0)
				{
					this.path.Clear();
				}
				this.current=null;
				this.start=true;
			}

			#endregion

			#region IEnumerator Members

			object IEnumerator.Current
			{
				[DebuggerStepThrough]
				get
				{
					return this.Current;
				}
			}

			#endregion

			#region IDisposable Members
			[DebuggerStepThrough]
			public void Dispose()
			{
				this.verison=0;
				if (this.trie!=null)
				{
					this.trie=null;
				}
				if (this.path!=null)
				{
					this.path.Clear();
					this.path=null;
				}
				this.current=null;
			}

			#endregion

			public int CurrentCount
			{
				get
				{
					this.CheckVersion();
					int retval=0;
					if (this.current!=null)
					{
						retval=this.current.TerminiatorCount;
					}
					return retval;
				}
			}

			[DebuggerStepThrough]
			private string MakeString()
			{
				StringBuilder buffer = new StringBuilder(64);
				IRange<string> range = null;
				for (int index=0;index<this.path.Count;index++)
				{
					range=this.path[index].Node.Range;
					if (range!=null)
					{
						buffer.Append(
							range.Container,
							range.Start,
							range.Length
						);
					}
				}
				range=this.current.Range;
				if (range!=null)
				{
					buffer.Append(
						range.Container,
						range.Start,
						range.Length
					);
				}
				return buffer.ToString();
			}

			[DebuggerStepThrough]
			private void CheckVersion()
			{
				if (this.verison!=this.trie.version)
				{
					throw new InvalidOperationException("trie has changed");
				}
			}
		} 
		*/
		#endregion

		public class StringTrieEnumerator : ATrieEnumerator<string>
		{
			private StringBuilder buffer;

			public StringTrieEnumerator(StringTrie trie)
				: base(trie)
			{
				this.buffer = new StringBuilder(256);
			}

			protected override string ValueFromPath(List<ATrieEnumerator<string>.TrieEnumeratorNode> path)
			{
				//StringBuilder buffer = new StringBuilder(64);
				IRange<string> range = null;
				for (int index=0;index<path.Count;index++)
				{
					range=path[index].Node.Range;
					if (range!=null)
					{
						this.buffer.Append(range.Container,range.Start,range.Length);
					}
				}
				range=this.CurrentNode.Range;
				if (range!=null)
				{
					this.buffer.Append(range.Container,range.Start,range.Length);
				}
				string retval = this.buffer.ToString();
				this.buffer.Remove(0,this.buffer.Length);
				return retval;
			}

			public override void Dispose()
			{
				this.buffer=null;
				base.Dispose();
			}
		}

		[DebuggerStepThrough]
		public StringTrie()
			: base(
				new StringRangeStrategy(),
				//new ArrayTrieNodeStrategy<string>(TrieOptions.None)
				new LinkedTrieNodeStrategy<string>(TrieOptions.None)
			)
		{
		}


		public void Insert(string value)
		{
			if (value!=null && value.Length>0)
			{
				//this.Insert(this.CreateRange(container,0,container.Length));
				this.Insert(this.RangeStategy.Create(value,0,value.Length));
			}
		}

		public void Delete(string value)
		{
			if (value==null)
			{
				throw new ArgumentNullException("value","value is null");
			}
			this.Delete(value,0,value.Length);
		}


		private enum ParseState
		{
			Start=0,
			Separator=1,
			Content=2,
			End=4
		}

		#region char separator methods

		public static void Split(StringRange range,Trie<string> trie,char[] separators,StringSplitOptions options)
		{
			Split(range,trie,separators,int.MaxValue,options);
		}
		public static void Split(
			StringRange range,
			Trie<string> trie,
			char[] separators,
			int maximum,
			StringSplitOptions options
		)
		{
			int count=-1;
			if (maximum>0)
			{
				if ((options&StringSplitOptions.RemoveEmptyEntries)==StringSplitOptions.RemoveEmptyEntries)
				{
					CreateSparseRangeList(
						range,
						trie,
						separators,
						maximum,
						out count
					);
				}
				else
				{
					CreateNormalRangeList(
						range,
						trie,
						separators,
						maximum,
						out count
					);
				}
				switch (count)
				{
					case -1:
						throw new InvalidOperationException("invalid count returned from CreateRangeList");
					case 0:
						//retval=new string[0] { };
						break;
					case 1:
						//retval = new string[1] { root.ToString() };
						break;
					default:
						//retval=StringRangeListToStringArray(root,count);
						break;
				}
			}
			//return retval;
		}

		public static void CreateNormalRangeList(
			StringRange range,
			Trie<string> trie,
			char[] separators,
			int maximum,
			out int count
		)
		{
			count=-1;
		}
		public static void CreateSparseRangeList(
			StringRange range,
			Trie<string> trie,
			char[] separators,
			int maximum,
			out int count
		)
		{
			// this method uses a very simple state transducer to move
			// between parser states on input and take actions based on
			// the movement between states.
			// 
			// s -> S
			// s -> C	open content
			// C -> S	close open content
			// C -> C
			// C -> e	close open content
			// S -> S
			// S -> C	open new content
			// S -> e

			count=0;

			string value = range.Container;
			int start = range.Start;
			int length = range.Length;

			//TSegment root = null;
			//TSegment current = null;
			int absoluteStart=-1;
			int absoluteLength=(start+length);

			ParseState state = ParseState.Start;

			if (length>0)
			{
				if (Array.IndexOf<char>(separators,value[0])>=0) // s -> S
				{
					state=ParseState.Separator;
				}
				else				// s -> C
				{
					//root=allocator.Allocate();
					//current=root;
					//current.Set(start,-1,value,null);
					absoluteStart=start;
					count+=1;
					state=ParseState.Content;
				}

				char character = '\0';
				int absoluteIndex=-1;
				bool separator=false;
				for (int index=1;index<length && count<maximum;index++)
				{
					absoluteIndex=(start+index);
					character=value[absoluteIndex];
					separator=(Array.IndexOf<char>(separators,character)>=0);
					switch (state)
					{
						case ParseState.Content:
							if (separator)		// C -> S
							{
								//current.Length=(absoluteIndex-current.Start);
								trie.Insert(value,absoluteStart,(absoluteIndex-absoluteStart));
								state=ParseState.Separator;
							}
							break;
						case ParseState.Separator:
							if (!separator)		// S -> C
							{
								//if (current==null)
								//{
								//	root=allocator.Allocate();
								//	current=root;
								//}
								//else
								//{
								//	current.Next=allocator.Allocate();
								//	current=(TSegment)current.Next;
								//}
								//current.Set(absoluteIndex,-1,value,null);
								absoluteStart=absoluteIndex;
								count+=1;
								state=ParseState.Content;
							}
							break;
						case ParseState.Start:
						case ParseState.End:
							throw new InvalidOperationException(string.Format("invalid parse state '{0}'",state));
					}
					//state=((separator)?ParseState.Separator:ParseState.Content);
				}
			}

			if (count<maximum)
			{
				switch (state)
				{
					case ParseState.Content: // C -> e
						//current.Length=(length-current.Start);
						trie.Insert(value,absoluteStart,(absoluteLength-absoluteStart));
						break;
					case ParseState.End:
						throw new InvalidOperationException(string.Format("invalid parse state '{0}'",state));
				}
			}
			else
			{
				//current.Length=(start+length)-current.Start;
				trie.Insert(value,absoluteStart,(absoluteLength-absoluteStart));
			}
			state=ParseState.End;

			//return root;
		}

		#endregion

		#region string separator methods
		private static void CreateNormalRangeList<TSegment>(
			StringRange range,
			Trie<string> trie,
			string[] separators,
			int maximum,
			out int count
		)
			//where TSegment : StringSegment
		{
			// this method uses a very simple state transducer to move
			// between parser states on input and take actions based on
			// the movememnt between states.
			// 
			// s -> S	add separator
			// s -> C	open content
			// C -> S	close content
			// C -> C
			// C -> e	close content
			// S -> S	add separator
			// S -> C	open new content
			// S -> e	add separator

			count=0;

			string value = range.Container;
			int start = range.Start;
			int length = range.Length;

			//TSegment root = null;
			//TSegment current = null;

			ParseState state = ParseState.Start;

			int absoluteIndex=start;
			int absoluteLength=(start+length);
			int separatorIndex=-1;
			int nextIndex=0;

			if (length>0)
			{
				while (
					(
						nextIndex=IndexOfAnyString(
							separators,
							value,
							absoluteIndex,
							(absoluteLength-absoluteIndex),
							out separatorIndex
						)
					)>=0
					&&
					nextIndex<=absoluteLength
					&&
					count<maximum
				)
				{
					if (nextIndex>absoluteIndex)
					{
						switch (state)
						{
							case ParseState.Start: // s -> C
								//root=allocator.Allocate();
								//current=root;
								break;
							case ParseState.Separator: // S -> C
								//current.Next=allocator.Allocate();
								//current=(TSegment)current.Next;
								break;
							default:
								throw new InvalidOperationException(string.Format("invalid parse state '{0}'",state));
						}
						//current.Set(absoluteIndex,(nextIndex-absoluteIndex),value,null);
						trie.Insert(value,absoluteIndex,(nextIndex-absoluteIndex));
						count+=1;
						state=ParseState.Content;
					}
					switch (state)
					{
						case ParseState.Start: // s -> S
							//root=allocator.Allocate();
							//current=root;
							//current.Set(absoluteIndex,0,value,null);
							trie.Insert(value,absoluteIndex,0);
							count+=1;
							break;
						case ParseState.Separator: // S -> S
							//current.Next=allocator.Allocate();
							//current=(TSegment)current.Next;
							//current.Set(absoluteIndex,0,value,null);
							trie.Insert(value,absoluteIndex,0);
							count+=1;
							break;
						case ParseState.Content:
							break;
						default:
							throw new InvalidOperationException(string.Format("invalid parse state '{0}'",state));
					}
					state=ParseState.Separator;

					absoluteIndex=(nextIndex+separators[separatorIndex].Length);
				}

			}

			//if (count<maximum)
			//{
				switch (state)
				{
					case ParseState.Start: // s -> e
						// the string has no length, add an empty entry
						//trie.Insert(value,absoluteIndex,(absoluteLength-absoluteIndex));
						//count+=1;
						//break;
					case ParseState.Content: // C -> e
					case ParseState.Separator: // S -> e
						//if (absoluteIndex<absoluteLength)
						//{
							// space left and no more separators found, must be content
							trie.Insert(value,absoluteIndex,(absoluteLength-absoluteIndex));
							count+=1;
						//}
						//else if (absoluteIndex==absoluteLength)
						//{
						//	// no items left but positioned on the last character
						//	// the string ends with a separator so add the trailer
						//	trie.Insert(value,absoluteIndex,0);
						//	count+=1;
						//}
						break;
					default:
						throw new InvalidOperationException(string.Format("invalid parse state '{0}'",state));
				}
				state=ParseState.End;
			//}
			//else
			//{
			//	//if (current==null)
			//	//{
			//	//    root=allocator.Allocate();
			//	//    current=root;
			//	//    current.Set(absoluteIndex,(absoluteLength-absoluteIndex),value,null);
			//	//    count+=1;
			//	//}
			//	//else
			//	//{
			//	//    current.Length=(absoluteLength-current.Start);
			//	//}
			//	trie.Insert(value,absoluteIndex,(absoluteLength-absoluteIndex));
			//	state=ParseState.End;
			//}

			//return root;
		}

		[DebuggerStepThrough]
		private static int IndexOfAnyString(string[] separators,string value,int start,int count,out int separator)
		{
			int foundIndex=-1;
			int separatorLength=-1;
			separator=-1;
			for (int index=0;index<count;index++)
			{
				for (int separatorIndex=0;separatorIndex<separators.Length;separatorIndex++)
				{
					if (
						(separatorLength=separators[separatorIndex].Length)<=(count-index) &&
						string.Compare(
							value,(start+index),
							separators[separatorIndex],0,
							separatorLength,
							StringComparison.Ordinal
						)==0
					)
					{
						separator=separatorIndex;
						break;
					}
				}
				if (separator>=0)
				{
					foundIndex=(start+index);
					break;
				}
			}
			return foundIndex;
		}

		#endregion


		#region IEnumerable<string> Members
		[DebuggerStepThrough]
		public IEnumerator<string> GetEnumerator()
		{
			return new StringTrieEnumerator(this);
		}

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		#endregion
	}

}